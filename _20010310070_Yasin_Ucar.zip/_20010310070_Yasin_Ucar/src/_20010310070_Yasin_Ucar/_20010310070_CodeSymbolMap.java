package _20010310070_Yasin_Ucar;

import java.util.*;

public class _20010310070_CodeSymbolMap {
	private static HashMap<String, String> codeSymbolMap;

	public static void setCodeSymbolMap() {
		codeSymbolMap = new HashMap<>();
		codeSymbolMap.put("0000", "AND");
		codeSymbolMap.put("1000", "AND");
		codeSymbolMap.put("0001", "ADD");
		codeSymbolMap.put("1001", "ADD");
		codeSymbolMap.put("0010", "LDA");
		codeSymbolMap.put("1010", "LDA");
		codeSymbolMap.put("0011", "STA");
		codeSymbolMap.put("1011", "STA");
		codeSymbolMap.put("0100", "BUN");
		codeSymbolMap.put("1100", "BUN");
		codeSymbolMap.put("0101", "BSA");
		codeSymbolMap.put("1101", "BSA");
		codeSymbolMap.put("0110", "ISZ");
		codeSymbolMap.put("1110", "ISZ");
		codeSymbolMap.put("0111100000000000", "CLA");
		codeSymbolMap.put("0111010000000000", "CLE");
		codeSymbolMap.put("0111001000000000", "CMA");
		codeSymbolMap.put("0111000100000000", "CME");
		codeSymbolMap.put("0111000010000000", "CIR");
		codeSymbolMap.put("0111000001000000", "CIL");
		codeSymbolMap.put("0111000000100000", "INC");
		codeSymbolMap.put("0111000000010000", "SPA");
		codeSymbolMap.put("0111000000001000", "SNA");
		codeSymbolMap.put("0111000000000100", "SZA");
		codeSymbolMap.put("0111000000000010", "SZE");
		codeSymbolMap.put("0111000000000001", "HLT");
		codeSymbolMap.put("1111100000000000", "INP");
		codeSymbolMap.put("1111010000000000", "OUT");
		codeSymbolMap.put("1111001000000000", "SKI");
		codeSymbolMap.put("1111000100000000", "SKO");
		codeSymbolMap.put("1111000010000000", "ION");
		codeSymbolMap.put("1111000001000000", "IOF");
	}

	public static String getSymbolName(String instruction) {
		for (String code : codeSymbolMap.keySet()) {
			if (code.equals(instruction)) {
				return codeSymbolMap.get(code);
			}
		}
		return getSymbolName(instruction.substring(0, 4));
	}
}
