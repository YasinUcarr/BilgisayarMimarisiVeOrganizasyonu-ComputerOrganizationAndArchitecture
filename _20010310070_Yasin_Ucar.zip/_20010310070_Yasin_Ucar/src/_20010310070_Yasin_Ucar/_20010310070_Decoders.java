package _20010310070_Yasin_Ucar;

public class _20010310070_Decoders implements _20010310070_IDecoder {
	private static String[] decoderOuput;

	public static String get3x8DecodedValue(String inputValue) {
		decoderOuput = new String[8];
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("0")) {
			decoderOuput[0] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("1")) {
			decoderOuput[1] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("0")) {
			decoderOuput[2] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("1")) {
			decoderOuput[3] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("0")) {
			decoderOuput[4] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("1")) {
			decoderOuput[5] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("0")) {
			decoderOuput[6] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("1")) {
			decoderOuput[7] = "1";
		}
		return getOutputValue();
	}

	public static String get4x16DecodedValue(String inputValue) {
		decoderOuput = new String[16];
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[0] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[1] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[2] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[3] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[4] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[5] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[6] = "1";
		}
		if (inputValue.substring(0, 1).equals("0") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[7] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[8] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[9] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[10] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("0")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[11] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[12] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("0") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[13] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("0")) {
			decoderOuput[14] = "1";
		}
		if (inputValue.substring(0, 1).equals("1") && inputValue.substring(1, 2).equals("1")
				&& inputValue.substring(2, 3).equals("1") && inputValue.substring(3, 4).equals("1")) {
			decoderOuput[15] = "1";
		}

		return getOutputValue();
	}

	private static String getOutputValue() {
		for (int i = 0; i < decoderOuput.length; i++) {
			if (decoderOuput[i] != null) {
				return String.valueOf(i);
			}
		}
		return null;
	}

}
