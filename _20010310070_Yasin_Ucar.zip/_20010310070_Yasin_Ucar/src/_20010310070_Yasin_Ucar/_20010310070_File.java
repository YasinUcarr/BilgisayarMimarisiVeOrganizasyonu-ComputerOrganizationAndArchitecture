package _20010310070_Yasin_Ucar;

import java.util.*;
import java.io.*;

public class _20010310070_File {
	private static ArrayList<String> fileList;

	public static void read(String fileName) {
		fileList = new ArrayList<>();
		File file = new File(fileName);
		Scanner scanner;
		try {
			scanner = new Scanner(file);
			while (scanner.hasNextLine()) {
				fileList.add(scanner.nextLine());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(fileName + " dosyası okundu.");
	}

	public static ArrayList<String> getFileList() {
		return fileList;
	}
}
