package _20010310070_Yasin_Ucar;

public interface _20010310070_IDecoder {
	static String get3x8DecodedValue(String inputValue) {
		return inputValue;
	}

	static String get4x16DecodedValue(String inputValue) {
		return null;
	}
}
