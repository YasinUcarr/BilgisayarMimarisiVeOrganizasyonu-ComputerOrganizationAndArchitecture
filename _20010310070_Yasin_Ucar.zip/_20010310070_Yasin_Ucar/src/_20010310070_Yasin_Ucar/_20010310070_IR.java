package _20010310070_Yasin_Ucar;

public class _20010310070_IR {

	public static String getInstructionRegisterValue(String instruction) {
		return instruction.substring(4, instruction.length());
	}
}
