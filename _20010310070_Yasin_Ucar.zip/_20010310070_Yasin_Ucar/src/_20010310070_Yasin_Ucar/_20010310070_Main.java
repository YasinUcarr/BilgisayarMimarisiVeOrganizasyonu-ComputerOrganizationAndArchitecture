package _20010310070_Yasin_Ucar;

public class _20010310070_Main {

	public static void main(String[] args) {
		_20010310070_CodeSymbolMap.setCodeSymbolMap();
		_20010310070_File.read("RAM.txt");
		_20010310070_Ram.loadRam(_20010310070_File.getFileList());
		execute();
	}

	private static void execute() {
		int i = 0;
		while (i <= 15) {
			String instruction = _20010310070_Ram.getInstruction(i);
			String sequenceCounterValue = _20010310070_SC.getSequenceCounterValue(i);
			String decodedValue4T = _20010310070_Decoders.get4x16DecodedValue(sequenceCounterValue);
			String TSignal = "T" + decodedValue4T;
			System.out.print(TSignal + "	zamanında ");
			String IBitValue = "I = " + getIBitValue(instruction);
			System.out.print(IBitValue);
			String operationCodeValue = getOperationCodeValue(instruction);
			String decodedValue4D = _20010310070_Decoders.get3x8DecodedValue(operationCodeValue);
			String DSignal = " D" + decodedValue4D;
			System.out.print(DSignal + " aktif ");
			String instructionRegisterValue = "IR(11-0) = " + _20010310070_IR.getInstructionRegisterValue(instruction);
			System.out.print(instructionRegisterValue);
			String symbolName = _20010310070_CodeSymbolMap.getSymbolName(instruction);
			System.out.println(" buyruk = " + symbolName);
			waitMs(1000);
			i++;
		}
	}

	private static String getIBitValue(String instruction) {
		return instruction.substring(0, 1);
	}

	private static String getOperationCodeValue(String instruction) {
		return instruction.substring(1, 4);
	}

	private static void waitMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
