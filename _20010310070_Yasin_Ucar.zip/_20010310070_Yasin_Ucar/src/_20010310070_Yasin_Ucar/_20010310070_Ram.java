package _20010310070_Yasin_Ucar;

import java.util.*;

public class _20010310070_Ram {
	private static ArrayList<String> ram;

	public static void loadRam(ArrayList<String> instructions) {
		ram = new ArrayList<>();
		for (String instruction : instructions) {
			ram.add(instruction);
		}
	}

	public static String getInstruction(int index) {
		return ram.get(index);
	}
}
