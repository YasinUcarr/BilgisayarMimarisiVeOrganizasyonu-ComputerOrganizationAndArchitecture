package _20010310070_Yasin_Ucar;

public class _20010310070_SC {
	private static String sequenceCounter;

	public static String getSequenceCounterValue(int time) {
		String binaryValue = Integer.toBinaryString(time);
		sequenceCounter = String.format("%4s", binaryValue).replace(' ', '0');

		return sequenceCounter;
	}
}
